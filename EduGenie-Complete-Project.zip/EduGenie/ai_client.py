from functools import lru_cache

from google import genai

from config import settings


class GeminiNotConfiguredError(RuntimeError):
    """Raised when the Gemini API key is missing."""


@lru_cache
def get_client() -> genai.Client:
    if not settings.gemini_api_key:
        raise GeminiNotConfiguredError(
            "GEMINI_API_KEY is not configured. Add it to your .env file."
        )
    return genai.Client(api_key=settings.gemini_api_key)


def generate_text(prompt: str) -> str:
    client = get_client()
    response = client.models.generate_content(
        model=settings.gemini_model,
        contents=prompt,
    )
    text = (response.text or "").strip()
    if not text:
        raise RuntimeError("Gemini returned an empty response.")
    return text


def generate_structured(prompt: str, response_schema):
    client = get_client()
    response = client.models.generate_content(
        model=settings.gemini_model,
        contents=prompt,
        config={
            "response_mime_type": "application/json",
            "response_schema": response_schema,
        },
    )
    if getattr(response, "parsed", None) is not None:
        return response.parsed
    return response.text
