from ai_client import generate_text

SYSTEM_STYLE = """
You are EduGenie, an educational assistant.
Answer accurately and concisely.
Use simple language suitable for a student.
Prefer short sections or bullet points when they improve clarity.
Do not invent sources, quotations, statistics, or citations.
If the question is ambiguous, state the assumption you are making.
"""


def answer_question(question: str) -> str:
    prompt = f"""{SYSTEM_STYLE}

Student question:
{question}

Give the answer first, then a short explanation or example when useful.
"""
    return generate_text(prompt)
