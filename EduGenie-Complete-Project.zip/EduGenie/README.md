# EduGenie — Google Gemini Powered Learning Assistant

EduGenie is a lightweight educational assistant based on the supplied project document. It provides:

- Q&A
- Simple concept explanations
- Three-question MCQ generation with four options per question
- Educational passage summarization
- Personalized beginner-to-advanced learning paths

The backend uses FastAPI and the frontend uses plain HTML/CSS/JavaScript. Gemini is accessed through Google's current `google-genai` Python SDK.

## Important implementation note

The supplied document names **Gemini 1.5 Pro**. That model choice is historical. This implementation keeps the same architecture and capabilities but makes the Gemini model configurable and defaults to a current Gemini model through `GEMINI_MODEL`. If your Google AI Studio project does not have access to the configured model, set `GEMINI_MODEL` to another model available to your account.

The supplied document also specifies **LaMini-Flan-T5-783M** for local concept explanation. The local model is supported as an optional feature so the core application stays lightweight. Enable it with `USE_LOCAL_EXPLANATION=true` and install `requirements-local.txt`. If the local model fails and a Gemini key is configured, EduGenie falls back to Gemini.

## Project structure

```text
EduGenie/
├── main.py
├── config.py
├── schemas.py
├── ai_client.py
├── explanation_module.py
├── qna.py
├── quiz_module.py
├── summary_module.py
├── learning_path.py
├── requirements.txt
├── requirements-local.txt
├── .env.example
├── .gitignore
├── Dockerfile
├── run.sh
├── run.bat
├── README.md
├── templates/
│   └── index.html
├── static/
│   ├── style.css
│   └── app.js
└── tests/
    └── test_api.py
```

## VS Code setup

### 1. Install Python

Use Python 3.10 or newer.

Check:

```bash
python --version
```

### 2. Open the project

In VS Code, choose **File → Open Folder** and select the `EduGenie` folder.

### 3. Create a virtual environment

Windows PowerShell:

```powershell
python -m venv .venv
.venv\Scripts\Activate.ps1
```

Windows Command Prompt:

```bat
python -m venv .venv
.venv\Scripts\activate
```

macOS/Linux:

```bash
python3 -m venv .venv
source .venv/bin/activate
```

### 4. Install dependencies

```bash
python -m pip install --upgrade pip
pip install -r requirements.txt
```

Optional local LaMini explanation:

```bash
pip install -r requirements-local.txt
```

The first local-model run downloads the model from Hugging Face, so it needs additional disk space and network access.

### 5. Configure Gemini

Copy `.env.example` to `.env`:

```text
GEMINI_API_KEY=your_key_here
GEMINI_MODEL=gemini-3.8-flash
USE_LOCAL_EXPLANATION=false
```

Do not commit `.env` to Git.

### 6. Run

```bash
python -m uvicorn main:app --reload
```

Open:

```text
http://127.0.0.1:8000
```

API documentation is available at:

```text
http://127.0.0.1:8000/docs
```

Health check:

```text
http://127.0.0.1:8000/health
```

## Test the project

Run:

```bash
pytest
```

The tests cover page loading, health checking, and request validation without making Gemini API calls.

For functional AI testing in the browser, try:

1. Q&A: `Which is the largest ocean?`
2. Explain: `Pythagoras theorem`
3. Quiz: paste a paragraph of study material
4. Summary: paste a long educational paragraph
5. Learning Path: `SQL`, choose a level and weekly hours

## API examples

### Q&A

```bash
curl -X POST http://127.0.0.1:8000/qa ^
  -H "Content-Type: application/json" ^
  -d "{\"question\":\"What is photosynthesis?\"}"
```

On macOS/Linux, use `\` instead of `^` for line continuation.

### Explanation

```bash
curl -X POST http://127.0.0.1:8000/explain \
  -H "Content-Type: application/json" \
  -d '{"topic":"Pythagoras theorem"}'
```

### Quiz

```bash
curl -X POST http://127.0.0.1:8000/quiz \
  -H "Content-Type: application/json" \
  -d '{"text":"Photosynthesis is the process by which green plants use sunlight, carbon dioxide, and water to make glucose and release oxygen."}'
```

### Summary

```bash
curl -X POST http://127.0.0.1:8000/summarize \
  -H "Content-Type: application/json" \
  -d '{"text":"Paste a longer educational passage here..."}'
```

### Learning path

```bash
curl -X POST http://127.0.0.1:8000/learn/recommendations \
  -H "Content-Type: application/json" \
  -d '{"topic":"SQL","learner_level":"beginner","weekly_hours":5}'
```

## Troubleshooting

### `GEMINI_API_KEY is not configured`

Create `.env` in the project root and add your API key. Restart the Uvicorn process after changing `.env`.

### Model not found / permission error

Change `GEMINI_MODEL` to a Gemini model available to your Google AI Studio project.

### Local explanation is slow

That is expected for a CPU-based LaMini model. Set:

```text
USE_LOCAL_EXPLANATION=false
```

to use Gemini for explanations.

### Port 8000 is already in use

Run:

```bash
python -m uvicorn main:app --reload --port 8001
```

Then open `http://127.0.0.1:8001`.

## Security notes

- Keep the Gemini API key only in environment variables.
- Never put the API key in `static/app.js` or `index.html`.
- The backend validates input sizes before sending requests to the model.
- AI output should still be reviewed by learners/teachers for high-stakes educational use.
