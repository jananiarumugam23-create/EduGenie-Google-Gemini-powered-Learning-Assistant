from ai_client import generate_structured
from schemas import LearningPathResponse


def get_learning_recommendations(
    topic: str,
    learner_level: str = "beginner",
    weekly_hours: int = 5,
):
    prompt = f"""
Create a personalized learning path for the topic "{topic}".

Learner level: {learner_level}
Available study time: {weekly_hours} hours per week.

Requirements:
- Start at the learner's level and progress toward advanced material.
- Include 3 to 6 stages.
- Each stage must have concrete topics, suggested resource types/names
  (books, documentation, courses, articles, or videos), and practice activities.
- Keep the plan realistic for the available weekly study time.
- Do not invent URLs. If a resource is not a specific known title, describe
  the resource type instead.
- Return only data matching the requested structured schema.
"""
    result = generate_structured(prompt, LearningPathResponse)
    if isinstance(result, LearningPathResponse):
        return result.model_dump()
    return LearningPathResponse.model_validate_json(result).model_dump()
