from ai_client import generate_text


def summarize_text(text: str) -> str:
    prompt = f"""
You are EduGenie, a study assistant. Summarize the educational passage below.
Keep the important facts, definitions, relationships, and conclusions.
Remove repetition and unnecessary wording.
Write in clear student-friendly language.
Use headings or bullet points if helpful. Do not add facts that are not supported
by the passage.

PASSAGE:
{text}
"""
    return generate_text(prompt)
