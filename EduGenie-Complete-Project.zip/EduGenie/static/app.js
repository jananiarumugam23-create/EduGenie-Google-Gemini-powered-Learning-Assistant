const task = document.getElementById("task");
const input = document.getElementById("input-text");
const inputLabel = document.getElementById("input-label");
const levelRow = document.getElementById("level-row");
const level = document.getElementById("level");
const hours = document.getElementById("hours");
const submitBtn = document.getElementById("submit-btn");
const result = document.getElementById("result");
const statusEl = document.getElementById("status");

const taskMeta = {
  qa: {
    label: "Your question",
    placeholder: "Example: Which is the largest ocean?",
    button: "Ask EduGenie",
  },
  explain: {
    label: "Topic to explain",
    placeholder: "Example: Explain the Pythagoras theorem",
    button: "Explain Topic",
  },
  quiz: {
    label: "Passage for the quiz",
    placeholder: "Paste a paragraph or study notes here. EduGenie will create 3 MCQs.",
    button: "Generate Quiz",
  },
  summarize: {
    label: "Text to summarize",
    placeholder: "Paste a long educational passage here.",
    button: "Summarize",
  },
  learn: {
    label: "Topic to learn",
    placeholder: "Example: SQL",
    button: "Build Learning Path",
  },
};

function updateForm() {
  const meta = taskMeta[task.value];
  inputLabel.textContent = meta.label;
  input.placeholder = meta.placeholder;
  submitBtn.textContent = meta.button;
  levelRow.classList.toggle("hidden", task.value !== "learn");
}

task.addEventListener("change", updateForm);
updateForm();

async function checkHealth() {
  try {
    const response = await fetch("/health");
    const data = await response.json();
    statusEl.textContent = data.gemini_configured ? "AI ready" : "API key needed";
  } catch {
    statusEl.textContent = "Backend unavailable";
  }
}
checkHealth();

function escapeHtml(value) {
  return String(value)
    .replaceAll("&", "&amp;")
    .replaceAll("<", "&lt;")
    .replaceAll(">", "&gt;")
    .replaceAll('"', "&quot;")
    .replaceAll("'", "&#039;");
}

function renderQuiz(data) {
  return `
    <h2>Quiz</h2>
    <p>Choose an answer for each question.</p>
    ${data.questions.map((q, i) => `
      <div class="quiz-question" data-question="${i}">
        <h3>${i + 1}. ${escapeHtml(q.question)}</h3>
        ${q.options.map((option, j) => `
          <label class="quiz-option">
            <input type="radio" name="q${i}" value="${escapeHtml(option)}">
            ${escapeHtml(option)}
          </label>
        `).join("")}
        <div class="quiz-feedback" id="feedback-${i}"></div>
      </div>
    `).join("")}
    <button type="button" id="check-quiz">Check Answers</button>
  `;
}

function renderLearningPath(data) {
  return `
    <h2>${escapeHtml(data.topic)} — Learning Path</h2>
    <p><strong>Level:</strong> ${escapeHtml(data.learner_level)}
       &nbsp; <strong>Estimated time:</strong> ${data.estimated_total_weeks} weeks</p>
    ${data.stages.map(stage => `
      <article class="stage">
        <h3>${escapeHtml(stage.level)} · ${stage.estimated_weeks} week(s)</h3>
        <strong>Topics</strong>
        <ul>${stage.topics.map(x => `<li>${escapeHtml(x)}</li>`).join("")}</ul>
        <strong>Suggested resources</strong>
        <ul>${stage.suggested_resources.map(x => `<li>${escapeHtml(x)}</li>`).join("")}</ul>
        <strong>Practice</strong>
        <ul>${stage.practice.map(x => `<li>${escapeHtml(x)}</li>`).join("")}</ul>
      </article>
    `).join("")}
  `;
}

function renderResponse(data, selectedTask) {
  if (selectedTask === "qa") {
    return `<h2>Answer</h2><div class="answer">${escapeHtml(data.answer)}</div>`;
  }
  if (selectedTask === "explain") {
    return `<h2>Explanation</h2><div class="answer">${escapeHtml(data.explanation)}</div>`;
  }
  if (selectedTask === "summarize") {
    return `<h2>Summary</h2><div class="answer">${escapeHtml(data.summary)}</div>`;
  }
  if (selectedTask === "quiz") return renderQuiz(data);
  if (selectedTask === "learn") return renderLearningPath(data);
}

async function submit() {
  const selectedTask = task.value;
  const text = input.value.trim();

  if (!text) {
    result.className = "result card error";
    result.innerHTML = "<strong>Please enter some text first.</strong>";
    return;
  }

  submitBtn.disabled = true;
  submitBtn.textContent = "Working…";
  result.className = "result card";
  result.innerHTML = "<p>EduGenie is thinking…</p>";

  const endpoints = {
    qa: "/qa",
    explain: "/explain",
    quiz: "/quiz",
    summarize: "/summarize",
    learn: "/learn/recommendations",
  };

  let body;
  if (selectedTask === "qa") body = { question: text };
  if (selectedTask === "explain") body = { topic: text };
  if (selectedTask === "quiz") body = { text };
  if (selectedTask === "summarize") body = { text };
  if (selectedTask === "learn") {
    body = {
      topic: text,
      learner_level: level.value,
      weekly_hours: Number(hours.value),
    };
  }

  try {
    const response = await fetch(endpoints[selectedTask], {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(body),
    });
    const data = await response.json();
    if (!response.ok) throw new Error(data.detail || "Request failed.");
    result.innerHTML = renderResponse(data, selectedTask);

    if (selectedTask === "quiz") {
      document.getElementById("check-quiz").addEventListener("click", () => {
        data.questions.forEach((q, i) => {
          const selected = document.querySelector(`input[name="q${i}"]:checked`);
          const feedback = document.getElementById(`feedback-${i}`);
          if (!selected) {
            feedback.textContent = "Please choose an option.";
          } else if (selected.value === q.correct_answer) {
            feedback.textContent = "Correct!";
          } else {
            feedback.textContent =
              `Not quite. Correct answer: ${q.correct_answer}. ${q.explanation}`;
          }
        });
      });
    }
  } catch (error) {
    result.className = "result card error";
    result.innerHTML = `<strong>Error:</strong> ${escapeHtml(error.message)}`;
  } finally {
    submitBtn.disabled = false;
    submitBtn.textContent = taskMeta[task.value].button;
  }
}

submitBtn.addEventListener("click", submit);
