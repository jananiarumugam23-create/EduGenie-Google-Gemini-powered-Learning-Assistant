from pydantic import BaseModel, Field, field_validator


def clean_text(value: str) -> str:
    value = value.strip()
    if not value:
        raise ValueError("Input cannot be empty.")
    return value


class QARequest(BaseModel):
    question: str = Field(min_length=2, max_length=12000)

    @field_validator("question")
    @classmethod
    def validate_question(cls, value: str) -> str:
        return clean_text(value)


class ExplainRequest(BaseModel):
    topic: str = Field(min_length=2, max_length=4000)

    @field_validator("topic")
    @classmethod
    def validate_topic(cls, value: str) -> str:
        return clean_text(value)


class QuizRequest(BaseModel):
    text: str = Field(min_length=20, max_length=12000)

    @field_validator("text")
    @classmethod
    def validate_text(cls, value: str) -> str:
        return clean_text(value)


class SummaryRequest(BaseModel):
    text: str = Field(min_length=20, max_length=30000)

    @field_validator("text")
    @classmethod
    def validate_text(cls, value: str) -> str:
        return clean_text(value)


class LearningPathRequest(BaseModel):
    topic: str = Field(min_length=2, max_length=3000)
    learner_level: str = Field(default="beginner", max_length=40)
    weekly_hours: int = Field(default=5, ge=1, le=40)

    @field_validator("topic", "learner_level")
    @classmethod
    def validate_text_fields(cls, value: str) -> str:
        return clean_text(value)


class QuizQuestion(BaseModel):
    question: str
    options: list[str] = Field(min_length=4, max_length=4)
    correct_answer: str
    explanation: str


class QuizResponse(BaseModel):
    questions: list[QuizQuestion] = Field(min_length=3, max_length=3)


class LearningStage(BaseModel):
    level: str
    topics: list[str]
    suggested_resources: list[str]
    practice: list[str]
    estimated_weeks: int = Field(ge=1, le=52)


class LearningPathResponse(BaseModel):
    topic: str
    learner_level: str
    estimated_total_weeks: int = Field(ge=1, le=156)
    stages: list[LearningStage] = Field(min_length=3, max_length=6)
