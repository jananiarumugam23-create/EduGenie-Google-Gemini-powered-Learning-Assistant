from ai_client import generate_structured
from schemas import QuizResponse


def generate_quiz(text: str):
    prompt = f"""
Create exactly 3 multiple-choice questions from the passage below.

Rules:
- Every question must be answerable from the passage.
- Every question has exactly 4 distinct options.
- correct_answer must exactly match one option.
- Include a short explanation of why the correct answer is correct.
- Mix recall and understanding questions.
- Return only data matching the requested structured schema.

PASSAGE:
{text}
"""
    result = generate_structured(prompt, QuizResponse)
    if isinstance(result, QuizResponse):
        return result.model_dump()
    return QuizResponse.model_validate_json(result).model_dump()
