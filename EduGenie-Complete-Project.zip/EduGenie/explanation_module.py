from functools import lru_cache

from ai_client import generate_text
from config import settings


@lru_cache(maxsize=1)
def _load_local_model():
    """
    Lazily loads the LaMini-Flan-T5 model only when local explanation is enabled.
    The optional local dependencies are intentionally separated from the core
    installation because the model and PyTorch are large.
    """
    from transformers import AutoTokenizer, AutoModelForSeq2SeqLM

    tokenizer = AutoTokenizer.from_pretrained(settings.local_model_name)
    model = AutoModelForSeq2SeqLM.from_pretrained(settings.local_model_name)
    return tokenizer, model


def _local_explanation(topic: str) -> str:
    import torch

    tokenizer, model = _load_local_model()
    prompt = (
        "Explain the following topic to a beginner. Use simple language, "
        "a short example, and no unnecessary detail: "
        f"{topic}"
    )
    inputs = tokenizer(
        prompt,
        return_tensors="pt",
        truncation=True,
        max_length=512,
    )
    with torch.no_grad():
        output = model.generate(
            **inputs,
            max_new_tokens=settings.local_explanation_max_new_tokens,
            num_beams=4,
            early_stopping=True,
        )
    return tokenizer.decode(output[0], skip_special_tokens=True).strip()


def _gemini_explanation(topic: str) -> str:
    prompt = f"""
Explain "{topic}" as a patient teacher.
Use:
1. A one-sentence definition.
2. A simple explanation.
3. One easy example or analogy.
4. Two key points to remember.

Keep the language beginner-friendly and concise.
"""
    return generate_text(prompt)


def explain_topic(topic: str) -> str:
    if settings.use_local_explanation:
        try:
            result = _local_explanation(topic)
            if result:
                return result
        except Exception as exc:
            if not settings.gemini_api_key:
                raise RuntimeError(
                    "Local LaMini explanation failed and Gemini fallback is unavailable: "
                    f"{exc}"
                ) from exc

    return _gemini_explanation(topic)
